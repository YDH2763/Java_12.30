package day08;

public @interface AllArgsConstructor {

}
