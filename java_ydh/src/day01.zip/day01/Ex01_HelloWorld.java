package day01;

public class Ex01_HelloWorld {
	
	// 한줄 주석 //가 나온 뒤부터 주석
	/* 여러줄 주석. 이사이에 있는 모든 글자들이 주석입니다. */
	/*
	 * 메소드를 설명할 때 사용하는 주석입니다. 
	 */
	//프로그램이 실행되려면 main이 있어야 한다.(main이 안들어가면 오류가 난다.)
	
	public static void main(String[] args) {
	
	// 들여쓰기는 Tab(스페이스바x4 만큼 띄어쓰게 됨)
	// 내어쓰기는 Shift + Tab

	System.out.println("Hello World!"); //Hello World!를 출력합니다.
	System.out.println("");
	
	}

}
