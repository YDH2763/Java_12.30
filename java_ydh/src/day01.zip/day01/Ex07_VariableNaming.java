package day01;

public class Ex07_VariableNaming {

	public static void main(String[] args) {
		int nem =10;
		
		int NUM= 10; //1.대소문자 구분, 서로 다른 변수
		
		//int int; 2.예약어(키워드)는 사용 불가
		
		//int 1num = 10; 3.변수명은 숫자로 시작할 수 없다.
		
		int _num = 10;
		//특수 문자는 _와 $만 가능
		//int n um = 10; 
		//int %num = 10; 
		
		//int num = 20;//5.중복 선언 불가
		
		

	}

}
