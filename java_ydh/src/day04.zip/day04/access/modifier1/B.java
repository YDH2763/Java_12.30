package day04.access.modifier1;

public class B {
	public String name;
	String address;
	private String num;
	
	public String getNum() {
		return num;
	}
	public void setNum(String num1) {
		num =num1;
	}
	
}
