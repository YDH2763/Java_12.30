package day01;

public class Ex09_variableText {

	public static void main(String[] args) {
		
		/*학생의 국어, 영어, 수학 성적을 저장하기 위한 변수를 선언하세요.
		 */
		int korea = 90;
		int math = 90;
		int english = 90;
		
		/*학생의 국어, 영어, 수학 성적의 평균을 저장하기 위한 변수를 선언하세요.*/
		int total = korea+math+english;
		double average= total/3;
		
		/*학생의 평점을 저장하기 위한 변수를 선언하세요. A,B,C,D,E,F만 저장*/
		char result;
	
		

	}

}
