package day04.access.modifier;

public class A {
	public String name;
	String address;
	private String num;

}
